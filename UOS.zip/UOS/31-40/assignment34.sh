# Generate a word frequency list for wonderland.txt. Hint: use grep, tr, sort, uniq (or anything else
# that you want)

#!/bin/bash

# Ensure the file exists
if [ ! -e "lab.txt" ]; then
    echo "Error: File v.txt not found!"
    exit 1
fi

# Extract words, convert to lowercase, and sort
grep -oE '\w+' lab.txt | tr '[:upper:]' '[:lower:]' | sort |
# Count word frequencies
uniq -c |
# Sort by frequency in descending order
sort -nr
