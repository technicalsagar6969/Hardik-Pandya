//  Take any txt file and count word frequencies in a file.(hint : file handling + basics )


#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <sstream>
#include <cctype>

using namespace std;

int main() {
    string filename;
    cout << "Enter the name of the file: ";
    cin >> filename;

    ifstream file(filename);

    if (!file.is_open()) {
        cout << "Error opening file.";
        return 1;
    }

    map<string, int> wordFreq;

    string word;
    while (file >> word) {
        // Removing punctuation marks from the word
        string cleanWord;
        for (char c : word) {
            if (isalpha(c)) {
                cleanWord += tolower(c);
            }
        }

        if (!cleanWord.empty()) {
            wordFreq[cleanWord]++;
        }
    }

    // Print the word frequencies
    cout << "Word frequencies:\n";
    for (const auto& pair : wordFreq) {
        cout << pair.first << ": " << pair.second << endl;
    }

    file.close();

    return 0;
}
