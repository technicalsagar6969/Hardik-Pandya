// Write a shell script that will take a filename as input and check if it is executable. 2. Modify the
// script in the previous question, to remove the execute permissions, if the file is executable.


#!/bin/bash

echo "Enter the filename"
read -r filename   

if [[ ! -e "${filename}" ]]; then
    echo "File does not exist"
fi

if [[ ! -x "${filename}" ]]; then
    echo "File is not executable"
else
    echo "File is executable"
fi

echo "Remove its execute permissions"
chmod -x "${filename}"

if [[ ! -x "${filename}" ]]; then
    echo "File is not executable"
else
    echo "File is executable"
fi
