#!/bin/bash

# Get the history of commands and count their frequency
history | awk '{print $2}' | sort | uniq -c | sort -nr > command_frequency.txt

# Print the top 5 commands
echo "Top 5 commands:"
head -n 5 command_frequency.txt

# Clean up temporary file
rm command_frequency.txt
