#!/bin/bash

FIFO_FILE=/tmp/myfifo

# Check if the FIFO file exists, if not, create it
if [ ! -p $FIFO_FILE ]; then
    mkfifo $FIFO_FILE
fi

echo "Reader process started"

while true; do
    if read line <$FIFO_FILE; then
        echo "Received: $line"
    fi
done

