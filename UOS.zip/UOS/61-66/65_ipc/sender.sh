#!/bin/bash

FIFO_FILE=/tmp/myfifo

# Check if the FIFO file exists, if not, create it
if [ ! -p $FIFO_FILE ]; then
    mkfifo $FIFO_FILE
fi

echo "Writer process started"
echo "Enter your message. Press Ctrl+D to exit."

while true; do
    read message
    if [ -z "$message" ]; then
        break
    fi
    echo "$message" > $FIFO_FILE
done

echo "Writer process exiting"

