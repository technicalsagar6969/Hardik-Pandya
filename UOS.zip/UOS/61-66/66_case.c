#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>

int main() {
    int pipefd[2]; // File descriptors for the pipe
    int nbytes; // Number of bytes read from the pipe
    pid_t pid;
    char readbuffer[80]; // Buffer to read data from the pipe

    // Create the pipe
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Fork a child process
    pid = fork();

    if (pid < 0) { // Error occurred
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) { // Parent process
        close(pipefd[0]); // Close the read end of the pipe

        // Write data to the pipe
        printf("Enter text: ");
        fgets(readbuffer, sizeof(readbuffer), stdin);
        write(pipefd[1], readbuffer, sizeof(readbuffer));
        close(pipefd[1]); // Close the write end of the pipe
    } 
    else { // Child process
        close(pipefd[1]); // Close the write end of the pipe
        nbytes = read(pipefd[0], readbuffer, sizeof(readbuffer)); // Read data from the pipe

        for (int i = 0; i < nbytes; i++) {
            readbuffer[i] = tolower(readbuffer[i]); // Convert to lowercase
        }

        printf("Lowercase text: %s", readbuffer);
        close(pipefd[0]); // Close the read end of the pipe
    }

    return 0;
}
