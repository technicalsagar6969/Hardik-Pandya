#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define FIFO_NAME "/tmp/my_fifo"

int main() {
    int fifo_fd;

    // Create FIFO
    if (mkfifo(FIFO_NAME, 0666) == -1) {
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }

    printf("FIFO created successfully\n");

    // Open FIFO for writing
    fifo_fd = open(FIFO_NAME, O_WRONLY);
    if (fifo_fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    printf("FIFO opened for writing\n");

    // Write data to FIFO
    const char *message = "Hello from Writer";
    if (write(fifo_fd, message, sizeof(message)) == -1) {
        perror("write");
        exit(EXIT_FAILURE);
    }

    printf("Data written to FIFO\n");

    // Close FIFO
    close(fifo_fd);

    return 0;
}
