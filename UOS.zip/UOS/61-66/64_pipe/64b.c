#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define FIFO_NAME "/tmp/my_fifo"

int main() {
    int fifo_fd;
    char buf[256];

    // Open FIFO for reading
    fifo_fd = open(FIFO_NAME, O_RDONLY);
    if (fifo_fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    printf("FIFO opened for reading\n");

    // Read data from FIFO
    ssize_t num_bytes = read(fifo_fd, buf, sizeof(buf));
    if (num_bytes == -1) {
        perror("read");
        exit(EXIT_FAILURE);
    }

    // Null-terminate the received data
    buf[num_bytes] = '\0';

    printf("Received message: %s\n", buf);

    // Close FIFO
    close(fifo_fd);

    return 0;
}

