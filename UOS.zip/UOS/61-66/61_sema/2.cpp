#include <iostream>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>

using namespace std;

int main() {
    // Get the key for the semaphore
    key_t key = ftok("/tmp", 'S');
    if (key == -1) {
        perror("ftok");
        return 1;
    }

    // Get the semaphore ID
    int semaphoreID = semget(key, 1, 0);
    if (semaphoreID == -1) {
        perror("semget");
        return 1;
    }

    // Perform the P operation
    struct sembuf operation;
    operation.sem_num = 0;  // Semaphore index
    operation.sem_op = -1;  // P operation
    operation.sem_flg = 0;  // No flags

    if (semop(semaphoreID, &operation, 1) == -1) {
        perror("semop P");
        return 1;
    }

    cout << "P operation performed successfully." << endl;

    return 0;
}
