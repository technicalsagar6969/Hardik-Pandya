#include <iostream>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>

using namespace std;

int main() {
    // Create a key for the semaphore
    key_t key = ftok("/tmp", 'S');
    if (key == -1) {
        perror("ftok");
        return 1;
    }

    // Create the semaphore
    int semaphoreID = semget(key, 1, IPC_CREAT | 0666);
    if (semaphoreID == -1) {
        perror("semget");
        return 1;
    }

    cout << "Semaphore created with ID: " << semaphoreID << endl;

    return 0;
}
