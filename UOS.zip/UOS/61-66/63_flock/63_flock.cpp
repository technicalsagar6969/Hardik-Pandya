#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <cstdlib>

using namespace std;

int main() {
    // Open a file
    int fd = open("test.txt", O_RDWR | O_CREAT, 0644);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    // Lock the file
    struct flock fl;
    fl.l_type = F_WRLCK;  // Exclusive write lock
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;  // Start from the beginning of the file
    fl.l_len = 0;    // Lock the entire file

    if (fcntl(fd, F_SETLKW, &fl) == -1) {
        perror("fcntl");
        close(fd);
        return 1;
    }

    cout << "File locked." << endl;

    // Write to the locked file
    const char *message = "This is a locked file.";
    if (write(fd, message, strlen(message)) == -1) {
        perror("write");
        close(fd);
        return 1;
    }

    cout << "Message written to the locked file." << endl;

    // Unlock the file
    fl.l_type = F_UNLCK;

    if (fcntl(fd, F_SETLK, &fl) == -1) {
        perror("fcntl");
        close(fd);
        return 1;
    }

    cout << "File unlocked." << endl;

    // Close the file
    close(fd);

    return 0;
}
