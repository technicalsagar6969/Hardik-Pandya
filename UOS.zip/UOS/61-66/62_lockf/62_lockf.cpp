#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <cstdlib>

using namespace std;

int main() {
    // Open a file
    int fd = open("example.txt", O_RDWR | O_CREAT, 0644);
    if (fd == -1) {
        perror("open");
        return 1;
    }

    // Lock the file
    if (lockf(fd, F_LOCK, 0) == -1) {
        perror("lockf");
        close(fd);
        return 1;
    }

    // Write to the locked file
    const char *message = "This is a locked file.";
    if (write(fd, message, strlen(message)) == -1) {
        perror("write");
        close(fd);
        return 1;
    }

    cout << "File locked and written successfully." << endl;

    // Unlock the file
    if (lockf(fd, F_ULOCK, 0) == -1) {
        perror("lockf");
        close(fd);
        return 1;
    }

    cout << "File unlocked." << endl;

    // Close the file
    close(fd);

    return 0;
}
