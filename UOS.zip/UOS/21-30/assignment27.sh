# Write a shell script to display the users on the system . (Using finger or who command).


#!/bin/bash

# Display the users on the system using the who command
echo "Users currently logged in to the system:"
who
