# Write a program to print “Hello World” message in bold, blink effect, and in different colors like
# red, blue etc.

#!/bin/bash

# ANSI escape codes for formatting
BOLD='\033[1m'
BLINK='\033[5m'
RED='\033[31m'
BLUE='\033[34m'
RESET='\033[0m'

# Print "Hello World" in bold, blink effect, and in different colors

while true; do
    echo  -e "${BOLD}${BLINK}${RED}Hello World${RESET}"
    clear
    echo  -e "${BOLD}${BLINK}${BLUE}Hello World${RESET}"
    clear
    
done

