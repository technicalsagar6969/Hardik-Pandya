# Write a python recursive function for prime number input limit in as parameter to
# it.

def is_prime(n,divisor=2):
    if n <= 2:
        return n == 2
    if n % divisor == 0:
        return False
    if divisor * divisor > n:
        return True
    return is_prime(n, divisor + 1)


def generate(limit,start=2):
    if(start<=limit):
        if(is_prime(start)):
            print(start)
        generate(limit,start+1)
    

limit=int(input("Enter Limut"))
generate(limit)