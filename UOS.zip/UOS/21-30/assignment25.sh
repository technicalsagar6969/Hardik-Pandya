# Write a shell script to find the given file in the system using find or locate command.


#!/bin/bash


echo "Enter the name of the file to search:"
read file_to_search



echo "Searching for '$file_to_search' using find command:"
find / -name "$file_to_search" 2>/dev/null
