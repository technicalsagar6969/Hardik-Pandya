# . Write a shell script to find whether given file exist or not in folder or on drive.

#!/bin/bash




echo "Enter the file name"
read fileName

echo "Enter the directory name"
read dirName

if [[ -f "${dirName}/${fileName}" ]]
then
    echo "File exist"
else
    echo "File does not exist"
fi


if [[ -e ${fileName} ]]
then
    echo "File exist"
else
    echo "File does not exist"
fi
