

# Write a shell script to download a webpage from given URL . (Using wget command).


#!/bin/bash

# Main program
echo "Enter the URL of the webpage to download:"
read url

echo "Downloading webpage from '$url'..."

# Download the webpage using wget command
wget "$url" -O webpage.html

echo "Webpage downloaded successfully!"
