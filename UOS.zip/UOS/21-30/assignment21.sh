# Write a program to sort 10 the given 10 numbers in ascending order using shell.

#!/bin/bash

echo "Sorting 10 numbers using shell..."

myarr=(10 9 8 7 6 5 4 3 2 1)

# for ((i = 0; i < 10; i++)); do
#     min_index=$i
#     for ((j = i + 1; j < 10; j++)); do
#         if [[ ${myarr[j]} -lt ${myarr[min_index]} ]]; then
#             min_index=$j
#         fi
#     done
#     if [[ $min_index -ne $i ]]; then
#         temp=${myarr[i]}
#         myarr[i]=${myarr[min_index]}
#         myarr[min_index]=$temp
#     fi
# done

# echo "Sorted numbers in ascending order:"


# for ((i = 0; i < 10; i++)); do
#     echo "${myarr[i]}"
# done

#!/bin/bash

# Define an array
my_array=(5 3 1 4 2)

# Sort the array using sort command
sorted_array=($(printf '%s\n' "${my_array[@]}" | sort -n))

# Print the sorted array
echo "Sorted array:"
echo "${sorted_array[@]}"



