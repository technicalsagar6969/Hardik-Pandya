#include<bits/stdc++.h>
using namespace std;

void alarmHandler(int signum)
{
    cout<<"Alarm Occured please wake up"<<endl;
    exit(0);
}
int main(int argc,int *argv)
{
    signal(SIGALRM,alarmHandler);
    int second;
    cout<<"Setup time in seconds so that "<<endl;
    cin>>second;
    alarm(second);
    cout<<"Alarm set"<<endl;
    while(1);
    return 0;
    

}