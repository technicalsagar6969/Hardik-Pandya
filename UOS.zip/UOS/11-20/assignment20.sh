# Write a program to check whether system is in network or not using ’ping’ command using shell
# script.
#!/bin/bash

# Define the IP address or domain name to ping
target="www.google.com"

# Ping the target
ping -c 1 $target 

# Check the exit status of the ping command
if [ $? == 0 ]
then
    echo "System is connected to the network."
else
    echo "System is not connected to the network."
fi


