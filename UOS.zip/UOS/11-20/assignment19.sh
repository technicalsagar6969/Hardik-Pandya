# Write a program to implement digital clock using shell script.
#!/bin/bash

while true
do
    clear
    echo "$(date +"%T")"
    sleep 1
done


