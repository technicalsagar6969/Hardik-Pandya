// Write a program to create 3 threads, first thread printing even no, second thread printing odd no.
// and third thread printing prime no.

import java.io.*;

class odd extends Thread {

    public void run()
    {
        for(int i=1;i<=10;i++)
        {
            if(i%2!=0)
            {
                System.out.println("Odd: "+i);
            }
        }
    }
}

class even extends Thread
{
    public void run()
    {
        for(int i=1;i<=10;i++)
        {
            if(i%2==0)
            {
                System.out.println("Even: "+i);
            }
        }
    }

}

class prime extends Thread
{
    public void run()
    {
        for(int i=1;i<=10;i++)
        {
            int count=0;
            for(int j=1;j<=i;j++)
            {
                if(i%j==0)
                {
                    count++;
                }
            }
            if(count==2)
            {
                System.out.println("Prime: "+i);
            }
        }
    }
}
public class assignment15
{
    public static void main(String [] args)
    {
        odd o=new odd();
        even e=new even();
        prime p=new prime();
        o.start();
        e.start();
        p.start();
    }
}