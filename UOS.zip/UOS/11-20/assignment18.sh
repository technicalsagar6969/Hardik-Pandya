#!/bin/bash

echo "enter your number a"
read a

echo "enter your number b"
read b

echo "choose 1 for addition"
echo "choose 2 for subtraction"
echo "choose 3 for multiplication"
echo "enter your choice"
read choice


if [[ $choice == '1' ]]; then 
    answer=$((a + b))
    echo "Result: $answer"
elif [[ $choice == '2' ]]; then
    answer=$((a - b))
    echo "Result: $answer"
elif [[ $choice == '3' ]]; then
    answer=$((a * b))
    echo "Result: $answer"
else
    echo "Invalid choice"
fi
