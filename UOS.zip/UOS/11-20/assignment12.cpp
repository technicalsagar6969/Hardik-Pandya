// Write a program to give statistics of a given file using stat system call. (few imp field like
// FAP, file type)


#include<bits/stdc++.h>
using namespace std;
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>


int main()
{
    struct stat file_stat;

    if(stat("vishwas.txt",&file_stat)==-1)
    {
        cout<<"File not found"<<endl;
        return 0;
    }

// st_ino: This field represents the inode number of the file. Inodes are data structures used by filesystems to represent files and directories. Each file or directory on a Unix-like filesystem is identified by a unique inode number.
// st_mode: This field represents the file mode and permissions. It contains information about the type of the file (e.g., regular file, directory, symbolic link) and the access permissions (e.g., read, write, execute) for the owner, group, and others.
// st_nlink: This field represents the number of hard links to the file. Hard links are additional directory entries that point to the same inode. The link count indicates how many hard links exist for the file. When a file is created, its link count is set to 1. Each time a hard link is created to the file, the link count is incremented by 1. When a hard link is removed, the link count is decremented by 1. When the link count reaches 0, the file is deleted.
// st_uid: This field represents the user ID of the owner of the file.
// st_gid: This field represents the group ID of the group that owns the file.
// st_rdev: This field represents the device ID for special files. For regular files, it is set to 0. For character and block special files, it contains the device numbers of the associated device. This field is used for device files like /dev/tty, /dev/null, etc.
    cout<<file_stat.st_ino<<endl;
    cout<<file_stat.st_mode<<endl;
    cout<<file_stat.st_nlink<<endl;
    cout<<file_stat.st_uid<<endl;
    cout<<file_stat.st_gid<<endl;
    cout<<file_stat.st_rdev<<endl;

}