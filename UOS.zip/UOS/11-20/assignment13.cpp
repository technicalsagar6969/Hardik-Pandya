// Write a program to give statistics of a given file using fstat system call. (few imp field like
// FAP, file type)

#include<bits/stdc++.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>

using namespace std;


int main(int argc,int *argv)
{
    struct stat st;
    int fd=open("lab.txt",O_RDONLY);
    if(fstat(fd,&st)==-1)
    {
        cout<<"Error in fstat"<<endl;
        return -1;
    }
    cout<<"file inode number"<<st.st_ino<<endl;
    cout<<"Size of the file is : "<<st.st_size<<endl;
    string file;
    if(S_ISREG(st.st_mode))
      file="Regular file";
    else if(S_ISDIR(st.st_mode))
     file=" Directory file";
    else if(S_ISBLK(st.st_mode))
     file="Block file";
    cout<<file<<endl;
    
    cout<<"File type is : "<<st.st_mode<<endl;
    return 0;
}
