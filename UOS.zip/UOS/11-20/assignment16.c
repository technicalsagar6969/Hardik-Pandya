#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 2
#define NUM_INCREMENTS 1000000

// Shared global counter
int counter = 0;

// Mutex for synchronizing access to the counter
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

// Function for the threads to execute
void *thread_function(void *arg) {
    int i;
    for (i = 0; i < NUM_INCREMENTS; i++) {
        // Lock the mutex before accessing the shared counter
        pthread_mutex_lock(&mutex);
        
        // Increment the counter
        counter++;
        
        // Unlock the mutex after accessing the shared counter
        pthread_mutex_unlock(&mutex);
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    int i, status;

    // Create thread s
    for (i = 0; i < NUM_THREADS; i++) {
        status = pthread_create(&threads[i], NULL, thread_function, NULL);
        if (status != 0) {
            fprintf(stderr, "Error creating thread %d. Exiting...\n", i);
            exit(EXIT_FAILURE);
        }
    }

    // Join threads
    for (i = 0; i < NUM_THREADS; i++) {
        status = pthread_join(threads[i], NULL);
        if (status != 0) {
            fprintf(stderr, "Error joining thread %d. Exiting...\n", i);
            exit(EXIT_FAILURE);
        }
    }

    // Print the final value of the counter
    printf("Final counter value: %d\n", counter);

    return 0;
}
