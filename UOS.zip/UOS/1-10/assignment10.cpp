// Write a program to use alarm and signal sytem call(check i/p from user within time)

#include<bits/stdc++.h>
using namespace std;

void signalHandler(int signum)
{
    cout << "data is not inputted" << endl;
    exit(0);

}

int main()
{
    signal(SIGALRM,signalHandler);


    alarm(5);

    
    cout<<"Enter command within 5 second"<<endl;
    string command;
    cin>>command;
    cout<<"data insrted"<<command<<endl;
    exit(0);
    return 0;

}