#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();
    if (pid == -1) {
        // Error occurred
        perror("fork");
        exit(0);
    } else if (pid == 0) {
        // Child process
        printf("Child process started\n");
        // Simulate some work in the child process
        for (int i = 0; i < 5; i++) {
            printf("Child: %d\n", i);
            sleep(1);
        }
        printf("Child process finished\n");
        exit(1);
    } else {
        // Parent process

        wait(NULL);
        printf("Parent process\n");
        // No wait call here
        printf("Parent process: Child finished with status ");
    }
    return 0;
}
