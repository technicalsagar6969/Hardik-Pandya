#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    // Set up arguments and environment variables
    char  *args[]= {"firefox", NULL};
    char *env[]= {"PATH=/usr/bin/firefox", NULL}; // Assuming firefox is located in /usr/bin

    // Use one of the exec system calls to launch Firefox
    // Here are a few variations:

    // Using execlp to search for executable in PATH
    // printf("Using execlp\n");
    // execlp("firefox", "firefox", NULL);

    // Using execvp to search for executable in PATH and pass arguments as an array
    // printf("Using execvp\n");
    // execvp("firefox", args);

    // Using execvpe to search for executable in PATH, pass arguments as an array, and set environment variables
    // printf("Using execvpe\n");
    // execvpe("firefox", args, env);

    // Using execle to pass environment variables as argument
    // printf("Using execle\n");
    execle("/usr/bin/firefox", "firefox", NULL,env);

    // Using execve to pass both arguments and environment variables
    // printf("Using execve\n");
    // execve("/usr/bin/firefox", args, env);

    // If any of the exec calls above fail, print an error message
    perror("exec");
    
    return 0;
}
