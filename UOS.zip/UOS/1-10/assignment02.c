// Write a program to use vfork system call(login name by child and password by parent)


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(int argc, char *argv[]) {
    
    int pid=vfork();
    if(pid==0) {
        printf("Enter Your Name");
        char name[100];
        scanf("%s",name);
    }
    else
    {
        wait(NULL);

        printf("Enter Your Password");
        char name[100];
        scanf("%s",name);
        exit(0);

    }
}
