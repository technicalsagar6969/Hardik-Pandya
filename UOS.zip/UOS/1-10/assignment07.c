// Write a program to demonstrate the exit system call use with wait & fork sysem call.

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>


int main()
{
    int pid=fork();
    if(pid==0)
    {
        printf("child process\n");
        for(int i=0;i<10;i++)
        {
            printf("%d\n",i);
            if(i==1)
               exit(0);
            sleep(1);
        }  
    }
    else
    {
        wait(NULL);
        printf("parent process terminated\n");
    }
}