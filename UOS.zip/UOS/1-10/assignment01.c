// Write a program to use fork system call to create 5 child processes and assign 5 operations
// to childs.

// Write a program to use fork system call to create 5 child processes and assign 5 operations
// to childs.

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<string.h>


int main()
{
    for(int i=1;i<=5;i++)
    {
        int pid = fork();
        if(pid == 0)
        {
            if(i == 1)
            {
                printf("Child %d: %d + %d = %d\n",i,10,20,10+20);
            }
            else if(i == 2)
            {
                printf("Child %d: %d - %d = %d\n",i,30,20,30-20);
            }
            else if(i == 3)
            {
                printf("Child %d: %d * %d = %d\n",i,10,20,10*20);
            }
            else if(i == 4)
            {
                printf("Child %d: %d / %d = %d\n",i,20,10,20/10);
            }
            else if(i == 5)
            {
                printf("Child %d: %d %% %d = %d\n",i,20,10,20%10);
            }
            exit(0);
        }
    }
}