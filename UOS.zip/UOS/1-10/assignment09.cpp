// Write a program to demonstrate the kill system call to send signals between related
// processes(fork).

#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

// Signal handler function
void signal_handler(int signum) {
    std::cout << "Received signal " << signum << std::endl;
}

int main() {
    int pid = fork();

    if (pid == -1) {
        // Fork failed
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        // Child process
        std::cout << "Child process running" << std::endl;

        // Register signal handler for SIGUSR1
        signal(SIGINT, signal_handler);

        std::cout << "Child process waiting for signal" << std::endl;
        // Child process waits indefinitely
        while (1) {
            sleep(1);
        }
    } else {
        // Parent process
        std::cout << "Parent process running" << std::endl;

        // Wait for a moment to ensure child is ready
        sleep(1);

        // Send SIGUSR1 signal to the child process
        std::cout << "Sending SIGUSR1 signal to child process" << std::endl;
        if (kill(pid, SIGINT) == -1) {
            perror("kill");
            exit(EXIT_FAILURE);
        }

        // Wait for the child process to finish
        wait(NULL);
    }

    return 0;
}
