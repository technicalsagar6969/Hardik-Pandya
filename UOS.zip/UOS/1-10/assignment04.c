#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    int pid = vfork();
    if (pid == 0) {
        // Child process
        execlp("firefox", "firefox", NULL);
        // If execlp fails, print an error message
        perror("execlp");
        // Terminate child process
        _exit(EXIT_FAILURE);
    } else if (pid > 0) {
        // Parent process
        // Wait for the child process to finish
        int status;
        waitpid(pid, &status, 0);
        printf("Child process finished\n");
    } else {
        // vfork() failed
        perror("vfork");
        exit(EXIT_FAILURE);
    }

    return 0;
}
