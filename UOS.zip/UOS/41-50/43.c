#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_SIZE 1024

int main() {
    int shmid;
    key_t key;
    int *shm, *s;

    // Create a unique key
    key = ftok(".", 's');
    if (key == -1) {
        perror("ftok");
        exit(1);
    }

    // Create the shared memory segment
    shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    // Attach to the shared memory
    shm = shmat(shmid, NULL, 0);
    if (shm == (int *) -1) {
        perror("shmat");
        exit(1);
    }

    // Fork a child process to take input from the user
    pid_t pid_input = fork();

    if (pid_input == -1) {
        perror("fork");
        exit(1);
    }

    if (pid_input == 0) { // Child process (input)
        printf("Enter the number of elements: ");
        int num_elements;
        scanf("%d", &num_elements);

        printf("Enter %d numbers:\n", num_elements);
        for (int i = 0; i < num_elements; i++) {
            scanf("%d", &shm[i]);
        }

        // Detach from the shared memory
        if (shmdt(shm) == -1) {
            perror("shmdt");
            exit(1);
        }

        exit(0);
    } else { // Parent process (sort)
        wait(NULL); // Wait for the input process to complete

        // Fork another child process to sort the numbers
        pid_t pid_sort = fork();

        if (pid_sort == -1) {
            perror("fork");
            exit(1);
        }

        if (pid_sort == 0) { // Child process (sort)
            // Sort the numbers using bubble sort
            int temp;
            for (int i = 0; i < SHM_SIZE / sizeof(int); i++) {
                for (int j = 0; j < SHM_SIZE / sizeof(int) - i - 1; j++) {
                    if (shm[j] > shm[j + 1]) {
                        temp = shm[j];
                        shm[j] = shm[j + 1];
                        shm[j + 1] = temp;
                    }
                }
            }

            // Detach from the shared memory
            if (shmdt(shm) == -1) {
                perror("shmdt");
                exit(1);
            }

            exit(0);
        } else { // Parent process (display)
            wait(NULL); // Wait for the sort process to complete

            // Fork another child process to display the sorted numbers
            pid_t pid_display = fork();

            if (pid_display == -1) {
                perror("fork");
                exit(1);
            }

            if (pid_display == 0) { // Child process (display)
                printf("Sorted numbers:\n");
                for (int i = 0; i < SHM_SIZE / sizeof(int); i++) {
                    printf("%d ", shm[i]);
                }
                printf("\n");

                // Detach from the shared memory
                if (shmdt(shm) == -1) {
                    perror("shmdt");
                    exit(1);
                }

                exit(0);
            }
        }
    }

    // Wait for all child processes to complete
    wait(NULL);
    wait(NULL);
    wait(NULL);

    // Remove the shared memory segment
    shmctl(shmid, IPC_RMID, NULL);

    return 0;
}
