#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

// Define semaphores
sem_t sem_f1;
sem_t sem_f2;

void *f1(void *arg) {
    // Ask for username
    printf("Enter username: ");
    char username[100];
    scanf("%s", username);

    // Signal that f1 is done
    sem_post(&sem_f1);

    pthread_exit(NULL);
}

void *f2(void *arg) {
    // Wait for f1 to finish
    sem_wait(&sem_f1);

    // Now execute f2
    printf("Enter password: ");
    char password[100];
    scanf("%s", password);

    pthread_exit(NULL);
}

int main() {
    // Initialize semaphores
    sem_init(&sem_f1, 0, 0);
    sem_init(&sem_f2, 0, 0);

    // Create threads for f1 and f2
    pthread_t thread_f1, thread_f2;

    pthread_create(&thread_f1, NULL, f1, NULL);
    pthread_create(&thread_f2, NULL, f2, NULL);

    // Wait for threads to finish
    pthread_join(thread_f1, NULL);
    pthread_join(thread_f2, NULL);

    // Destroy semaphores
    sem_destroy(&sem_f1);
    sem_destroy(&sem_f2);

    return 0;
}
