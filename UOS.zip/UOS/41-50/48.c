#include <stdio.h>
#include <omp.h>

int main() {
    int total_threads = 0;

    #pragma omp parallel
    {
        #pragma omp master
        {
            total_threads = omp_get_num_threads();
            printf("Total number of threads created: %d\n", total_threads);
        }

        int thread_num = omp_get_thread_num();
        printf("Thread %d reporting.\n", thread_num);
    }

    return 0;
}
