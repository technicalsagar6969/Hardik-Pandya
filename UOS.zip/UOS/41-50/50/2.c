#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

#define MSGSZ 128

typedef struct msgbuf {
    long mtype;
    char mtext[MSGSZ];
} message_buf;

int main() {
    int msqid;
    key_t key;
    message_buf rbuf, sbuf;
    size_t buf_length;

    // Generate a key for the message queue
    if ((key = ftok("msgq.txt", 'B')) == -1) {
        perror("ftok");
        exit(1);
    }

    // Get the message queue
    if ((msqid = msgget(key, 0644)) == -1) {
        perror("msgget");
        exit(1);
    }

    // Receive message
    if (msgrcv(msqid, &rbuf, MSGSZ, 1, 0) == -1) {
        perror("msgrcv");
        exit(1);
    }

    printf("Process 1: %s\n", rbuf.mtext);

    // Send reply
    sbuf.mtype = 2;
    strcpy(sbuf.mtext, "Loud and Clear");
    buf_length = strlen(sbuf.mtext) + 1;

    if (msgsnd(msqid, &sbuf, buf_length, 0) == -1) {
        perror("msgsnd");
        exit(1);
    }

    return 0;
}
