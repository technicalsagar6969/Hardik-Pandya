#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_SIZE 1024
#define DATA_FILE "data.txt"
#define RESULT_FILE "result.txt"

int main() {
    int shmid;
    key_t key;
    char *shm, *s;

    // Create a unique key
    key = ftok(".", 's');
    if (key == -1) {
        perror("ftok");
        exit(1);
    }

    // Create the shared memory segment
    shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    // Attach to the shared memory
    shm = shmat(shmid, NULL, 0);
    if (shm == (char *) -1) {
        perror("shmat");
        exit(1);
    }

    // Fork a child process
    pid_t pid = fork();

    if (pid == -1) {
        perror("fork");
        exit(1);
    }

    if (pid == 0) { // Child process (receiver)
        FILE *result_file = fopen(RESULT_FILE, "w");
        if (result_file == NULL) {
            perror("fopen");
            exit(1);
        }

        printf("Child process: Waiting for data...\n");

        // Wait for the parent process to write data
        while (*shm == 0)
            usleep(100);

        // Write the received data to a file
        fprintf(result_file, "%s", shm);
        printf("Child process: Received data and written to %s\n", RESULT_FILE);

        // Close the result file
        fclose(result_file);

        // Detach from the shared memory
        if (shmdt(shm) == -1) {
            perror("shmdt");
            exit(1);
        }

        exit(0);
    } else { // Parent process (sender)
        FILE *data_file = fopen(DATA_FILE, "r");
        if (data_file == NULL) {
            perror("fopen");
            exit(1);
        }

        printf("Parent process: Reading data from %s...\n", DATA_FILE);

        // Read data from the file
        fgets(shm, SHM_SIZE, data_file);

        // Close the data file
        fclose(data_file);

        printf("Parent process: Sending data to child process...\n");

        // Wait for the child process to complete
        wait(NULL);

        // Detach from the shared memory
        if (shmdt(shm) == -1) {
            perror("shmdt");
            exit(1);
        }

        // Remove the shared memory segment
        shmctl(shmid, IPC_RMID, NULL);
    }

    return 0;
}
