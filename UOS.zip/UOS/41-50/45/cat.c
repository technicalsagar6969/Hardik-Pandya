#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <file1> [<file2> ...]\n", argv[0]);
        return 1;
    }

    for (int i = 1; i < argc; i++) {
        FILE *file = fopen(argv[i], "r");
        if (file == NULL) {
            printf("Error: Cannot open file %s\n", argv[i]);
            continue;
        }

        char c;
        while ((c = fgetc(file)) != EOF) {
            putchar(c);
        }

        fclose(file);
    }

    return 0;
}
