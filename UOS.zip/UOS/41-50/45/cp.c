#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <source> <destination>\n", argv[0]);
        return 1;
    }

    FILE *source_file = fopen(argv[1], "r");
    if (source_file == NULL) {
        perror("fopen");
        return 1;
    }

    FILE *destination_file = fopen(argv[2], "w");
    if (destination_file == NULL) {
        perror("fopen");
        fclose(source_file);
        return 1;
    }

    char c;
    while ((c = fgetc(source_file)) != EOF) {
        fputc(c, destination_file);
    }

    fclose(source_file);
    fclose(destination_file);

    return 0;
}
