#include <stdio.h>

#define DEFAULT_NUM_LINES 10

int main(int argc, char *argv[]) {
    int num_lines = DEFAULT_NUM_LINES;
    if (argc > 1) {
        num_lines = atoi(argv[1]);
    }

    FILE *file = stdin;
    if (argc > 2) {
        file = fopen(argv[2], "r");
        if (file == NULL) {
            perror("fopen");
            return 1;
        }
    }

    int lines_printed = 0;
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file) != NULL && lines_printed < num_lines) {
        fputs(buffer, stdout);
        lines_printed++;
    }

    if (file != stdin) {
        fclose(file);
    }

    return 0;
}
