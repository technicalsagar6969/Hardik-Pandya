#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_SIZE 1024

int main() {
    int shmid;
    key_t key;
    void *shm;

    // Create a unique key
    key = ftok(".", 's');
    if (key == -1) {
        perror("ftok");
        exit(1);
    }

    // Fork a child process to create shared memory
    pid_t pid_create = fork();

    if (pid_create == -1) {
        perror("fork");
        exit(1);
    }

    if (pid_create == 0) { // Child process (create)
        printf("Child process (create): Creating shared memory...\n");

        // Create the shared memory segment
        shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
        if (shmid == -1) {
            perror("shmget");
            exit(1);
        }

        printf("Child process (create): Shared memory created with ID: %d\n", shmid);

        exit(0);
    } else { // Parent process (delete)
        wait(NULL); // Wait for the create process to complete

        // Fork another child process to delete shared memory
        pid_t pid_delete = fork();

        if (pid_delete == -1) {
            perror("fork");
            exit(1);
        }

        if (pid_delete == 0) { // Child process (delete)
            printf("Child process (delete): Deleting shared memory...\n");

            // Delete the shared memory segment
            if (shmctl(shmid, IPC_RMID, NULL) == -1) {
                perror("shmctl");
                exit(1);
            }

            printf("Child process (delete): Shared memory deleted\n");

            exit(0);
        } else { // Parent process (attach/detach)
            wait(NULL); // Wait for the delete process to complete

            // Fork another child process to attach/detach shared memory
            pid_t pid_attach_detach = fork();

            if (pid_attach_detach == -1) {
                perror("fork");
                exit(1);
            }

            if (pid_attach_detach == 0) { // Child process (attach/detach)
                printf("Child process (attach/detach): Attaching to shared memory...\n");

                // Attach to the shared memory
                shmid = shmget(key, SHM_SIZE, 0666);
                if (shmid == -1) {
                    perror("shmget");
                    exit(1);
                }

                shm = shmat(shmid, NULL, 0);
                if (shm == (void *) -1) {
                    perror("shmat");
                    exit(1);
                }

                printf("Child process (attach/detach): Attached to shared memory\n");

                // Wait for a while
                sleep(2);

                printf("Child process (attach/detach): Detaching from shared memory...\n");

                // Detach from the shared memory
                if (shmdt(shm) == -1) {
                    perror("shmdt");
                    exit(1);
                }

                printf("Child process (attach/detach): Detached from shared memory\n");

                exit(0);
            }
        }
    }

    // Wait for all child processes to complete
    wait(NULL);
    wait(NULL);
    wait(NULL);

    return 0;
}
