#include <iostream>
#include <unistd.h>
#include <semaphore.h>
#include <sys/wait.h>

using namespace std;

int main() {
    // Create a semaphore
    sem_t semaphore;
    sem_init(&semaphore, 0, 1); // Initialize the semaphore with initial value 1

    // Fork a child process
    pid_t pid = fork();

    if (pid == -1) {
        cerr << "Failed to fork." << endl;
        return 1;
    } else if (pid == 0) {
        // Child process
        sem_wait(&semaphore); // Wait for the semaphore
        cout << "Child process is running." << endl;
        sem_post(&semaphore); // Release the semaphore
    } else {
        // Parent process
        sem_wait(&semaphore); // Wait for the semaphore
        cout << "Parent process is running." << endl;
        sem_post(&semaphore); // Release the semaphore
        wait(NULL); // Wait for the child process to finish
    }

    // Destroy the semaphore
    sem_destroy(&semaphore);

    return 0;
}
