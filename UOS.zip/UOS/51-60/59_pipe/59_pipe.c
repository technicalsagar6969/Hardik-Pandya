#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>

#define BUFFER_SIZE 256

int main() {
    FILE *input_file = fopen("input.txt", "r");
    if (input_file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    fseek(input_file, 0, SEEK_END); // Move file pointer to end to get file size
    long input_length = ftell(input_file); // Get file size
    fseek(input_file, 0, SEEK_SET); // Move file pointer back to beginning

    char *input_text = (char *)malloc(input_length + 1); // Allocate buffer for input text
    if (input_text == NULL) {
        perror("Memory allocation failed");
        fclose(input_file);
        exit(EXIT_FAILURE);
    }

    fread(input_text, 1, input_length, input_file); // Read input text from file
    input_text[input_length] = '\0'; // Null terminate the string

    fclose(input_file);

    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) {
        perror("Pipe creation failed");
        free(input_text);
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("Fork failed");
        free(input_text);
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { // Child process
        close(pipe_fd[1]); // Close write end

        char buffer[BUFFER_SIZE];
        ssize_t bytes_read;

        while ((bytes_read = read(pipe_fd[0], buffer, BUFFER_SIZE)) > 0) {
            for (ssize_t i = 0; i < bytes_read; ++i) {
                buffer[i] = tolower(buffer[i]);
            }
            write(STDOUT_FILENO, buffer, bytes_read);
        }

        close(pipe_fd[0]); // Close read end
        free(input_text);
        exit(EXIT_SUCCESS);
    } else { // Parent process
        close(pipe_fd[0]); // Close read end

        write(pipe_fd[1], input_text, input_length);

        close(pipe_fd[1]); // Close write end
        free(input_text);
        wait(NULL); // Wait for child process to finish
        exit(EXIT_SUCCESS);
    }

    return 0;
}

