#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 1024

void to_lowercase(FILE *input_file) {
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;

    // Read from input file and convert to lowercase
    while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, input_file)) > 0) {
        for (ssize_t i = 0; i < bytes_read; i++) {
            buffer[i] = tolower(buffer[i]);
        }
        write(STDOUT_FILENO, buffer, bytes_read);
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Open the input file for reading
    FILE *input_file = fopen(argv[1], "r");
    if (input_file == NULL) {
        perror("fopen");
        return EXIT_FAILURE;
    }

    // Create a pipe
    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) {
        perror("pipe");
        return EXIT_FAILURE;
    }

    // Fork a child process
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return EXIT_FAILURE;
    }

    if (pid == 0) {
        // Child process
        close(pipe_fd[1]); // Close the write end of the pipe in the child

        // Redirect stdin to read from the pipe
        dup2(pipe_fd[0], STDIN_FILENO);

        // Close the read end of the pipe
        close(pipe_fd[0]);

        // Execute the filter (convert to lowercase)
        execlp("tr", "tr", "[:upper:]", "[:lower:]", NULL);
        perror("execlp");
        return EXIT_FAILURE;
    } else {
        // Parent process
        close(pipe_fd[0]); // Close the read end of the pipe in the parent

        // Redirect stdout to write to the pipe
        dup2(pipe_fd[1], STDOUT_FILENO);

        // Close the write end of the pipe
        close(pipe_fd[1]);

        // Call the function to convert to lowercase and write to pipe
        to_lowercase(input_file);

        // Close the input file
        fclose(input_file);

        // Wait for the child process to finish
        wait(NULL);
    }

    return EXIT_SUCCESS;
}
