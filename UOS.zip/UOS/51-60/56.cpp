#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define FIFO_PATH "my_pipe"

void parent_process() {
    int fd;
    char data[] = "Hello from parent!";

    // Create the FIFO named pipe
    mkfifo(FIFO_PATH, 0666);

    // Open the pipe for writing
    fd = open(FIFO_PATH, O_WRONLY);
    if (fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    // Send data to the child process
    printf("Parent process sending: %s\n", data);
    write(fd, data, strlen(data) + 1);

    // Close the pipe
    close(fd);

    printf("Parent process finished sending data.\n");
}

void child_process() {
    int fd;
    char buffer[256];

    // Open the pipe for reading
    fd = open(FIFO_PATH, O_RDONLY);
    if (fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    // Read data sent by the parent process
    read(fd, buffer, sizeof(buffer));
    printf("Child process received: %s\n", buffer);

    // Close the pipe
    close(fd);

    printf("Child process finished receiving data.\n");
}

int main() {
    // Create a child process
    int pid = fork();

    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        // Child process
        child_process();
    } else {
        // Parent process
        parent_process();
    }

    return 0;
}
