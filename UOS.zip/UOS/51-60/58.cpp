#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define FIFO_PATH "my_pipe"
#define BUFFER_SIZE 1024

void parent_process(const char *filename) {
    // Create the FIFO named pipe
    mkfifo(FIFO_PATH, 0666);

    // Open the pipe for writing
    int fd = open(FIFO_PATH, O_WRONLY);
    if (fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    // Open the file for reading
    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }

    // Read data from the file and write it to the pipe
    char buffer[BUFFER_SIZE];
    size_t bytes_read;
    while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
        write(fd, buffer, bytes_read);
    }

    // Close the file and the pipe
    fclose(file);
    close(fd);

    // Remove the FIFO named pipe
    unlink(FIFO_PATH);
}

void child_process() {
    // Open the pipe for reading
    int fd = open(FIFO_PATH, O_RDONLY);
    if (fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    // Read data from the pipe and write it to stdout
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;
    while ((bytes_read = read(fd, buffer, BUFFER_SIZE)) > 0) {
        write(STDOUT_FILENO, buffer, bytes_read);
    }

    // Close the pipe
    close(fd);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Create a child process
    pid_t pid = fork();

    if (pid == -1) {
        perror("fork");
        return EXIT_FAILURE;
    } else if (pid == 0) {
        // Child process
        child_process();
    } else {
        // Parent process
        parent_process(argv[1]);
    }

    return EXIT_SUCCESS;
}
