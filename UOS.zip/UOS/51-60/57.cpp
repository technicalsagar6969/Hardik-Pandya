
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Open the specified file for reading
    FILE *file = fopen(argv[1], "rb");
    if (file == NULL) {
        perror("fopen");
        return EXIT_FAILURE;
    }

    // Create a pipe
    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) {
        perror("pipe");
        return EXIT_FAILURE;
    }

    // Fork a child process
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return EXIT_FAILURE;
    }

    if (pid == 0) {
        // Child process
        close(pipe_fd[1]); // Close the write end of the pipe in the child

        // Redirect stdin to read from the pipe
        dup2(pipe_fd[0], STDIN_FILENO);

        // Execute a program to receive the file (e.g., cat)
        execlp("cat", "cat", NULL);
        perror("execlp");
        return EXIT_FAILURE;
    } else {
        // Parent process
        close(pipe_fd[0]); // Close the read end of the pipe in the parent

        char buffer[BUFFER_SIZE];
        size_t bytes_read;

        // Read data from the file and write it to the pipe
        while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
            write(pipe_fd[1], buffer, bytes_read);
        }

        // Close the write end of the pipe to signal EOF to the child
        close(pipe_fd[1]);

        // Wait for the child process to finish
        wait(NULL);
    }

    // Close the file
    fclose(file);
    return EXIT_SUCCESS;
}
