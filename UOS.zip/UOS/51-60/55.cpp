#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>



int main()
{
    int pid;
    int x,y;
    int fd[2];
    // 0 th fild descriptor used for redaing data and 1 decriptor used for writing data
    if(pipe(fd)==-1)
    {
        printf("Error in pipe\n");
        return 1;
    }
    pid=fork();

    if(pid==0)
    {
        printf("currently in child process\n");
        close(fd[0]);
        // reading data 

        printf("Entering the data for the yx\n");
        scanf("%d",&x);
        write(fd[1],&x,sizeof(int));
        close(fd[1]);
    }
    else
    {
        close(fd[1]);
        printf("reading data from the child process\n");
        read(fd[0],&y,sizeof(int));
        printf("The value of y is %d\n",y);
        close(fd[0]);
    }

}

